import React from 'react';
import SectionHeading from '../components/ui/SectionHeading';
import ContactSection from '../components/common/ContactSection';
import Button from '../components/ui/Button';

export const metadata = {
  title: "Digital Marketing | Best Social Media Agency | Mumbai, India",
  description: "Leverage digital and social media marketing with India's best Digital agency. We offer social media, website development, SEO, design, influencer marketing.",
};

export default function Page() {
  const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";
  return (
    <main className="flex-grow flex flex-col w-full font-sans">
      <ContactSection
        title="Work With Us"
        subtitle="Need a creative boost to launch a campaign, build a product, or grow your audience? Let's connect."
        theme="dark"
      />

    </main>
  );
}
