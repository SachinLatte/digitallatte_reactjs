"use client";

import React, { useState } from "react";
import Button from "../ui/Button";

export default function ContactSection({
  title = "Let's Talk Business",
  subtitle = "Have a brief, project enquiry, or just want to say hello? Drop us a line below.",
  theme = "dark"
}) {
  const isDark = theme === "dark";
  
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    message: ""
  });

  const [status, setStatus] = useState({
    submitting: false,
    success: false,
    error: null
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ submitting: true, success: false, error: null });

    // Mock API request delay
    setTimeout(() => {
      setStatus({
        submitting: false,
        success: true,
        error: null
      });
      setFormData({
        name: "",
        phone: "",
        email: "",
        message: ""
      });
    }, 1500);
  };

  return (
    <section className={`w-full py-16 md:py-24 px-6 transition-colors duration-500 ${
      isDark ? "bg-[#16110f] text-white" : "bg-[#ececec] text-[#16110f]"
    }`}>
      <div className="max-w-[800px] mx-auto text-center flex flex-col items-center">
        
        {/* Header */}
        <h2 className="text-[32px] sm:text-[38px] md:text-[45px] font-light uppercase tracking-[2px] leading-tight">
          {title.split(" ").map((word, idx) => 
            idx === 0 ? <span key={idx} className="font-bold mr-2">{word}</span> : <span key={idx} className="mr-2">{word}</span>
          )}
        </h2>
        <p className={`text-sm md:text-base mt-4 max-w-xl leading-relaxed ${
          isDark ? "text-neutral-400" : "text-neutral-600"
        }`}>
          {subtitle}
        </p>

        {/* Status Alerts */}
        {status.success && (
          <div className="w-full mt-8 bg-green-950/40 border border-green-850 text-green-300 px-6 py-4 rounded-xl text-sm max-w-xl text-left">
            <span className="font-bold block mb-1">Message Sent Successfully!</span>
            Thank you for reaching out to Digital Latte. We will get back to you shortly over email or phone.
          </div>
        )}

        {/* Contact Form */}
        <form onSubmit={handleSubmit} className="w-full mt-10 space-y-6 text-left max-w-xl">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Name Input */}
            <div className="flex flex-col">
              <label htmlFor="form-name" className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${
                isDark ? "text-neutral-400" : "text-neutral-600"
              }`}>
                Your Name *
              </label>
              <input
                id="form-name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder="John Doe"
                className={`px-4 py-3 rounded-xl border transition duration-300 text-sm focus:outline-none focus:border-[#e07f2a] ${
                  isDark 
                    ? "bg-[#221f1f] border-neutral-800 text-white placeholder-neutral-600" 
                    : "bg-white border-neutral-300 text-[#16110f] placeholder-neutral-450"
                }`}
              />
            </div>

            {/* Contact Phone */}
            <div className="flex flex-col">
              <label htmlFor="form-phone" className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${
                isDark ? "text-neutral-400" : "text-neutral-600"
              }`}>
                Phone Number *
              </label>
              <input
                id="form-phone"
                name="phone"
                type="tel"
                required
                value={formData.phone}
                onChange={handleChange}
                placeholder="+91 99999 99999"
                className={`px-4 py-3 rounded-xl border transition duration-300 text-sm focus:outline-none focus:border-[#e07f2a] ${
                  isDark 
                    ? "bg-[#221f1f] border-neutral-800 text-white placeholder-neutral-600" 
                    : "bg-white border-neutral-300 text-[#16110f] placeholder-neutral-450"
                }`}
              />
            </div>
          </div>

          {/* Email Address */}
          <div className="flex flex-col">
            <label htmlFor="form-email" className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${
              isDark ? "text-neutral-400" : "text-neutral-600"
            }`}>
              Email Address *
            </label>
            <input
              id="form-email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="hello@example.com"
              className={`px-4 py-3 rounded-xl border transition duration-300 text-sm focus:outline-none focus:border-[#e07f2a] ${
                isDark 
                  ? "bg-[#221f1f] border-neutral-800 text-white placeholder-neutral-600" 
                  : "bg-white border-neutral-300 text-[#16110f] placeholder-neutral-450"
              }`}
            />
          </div>

          {/* Message Textarea */}
          <div className="flex flex-col">
            <label htmlFor="form-message" className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${
              isDark ? "text-neutral-400" : "text-neutral-600"
            }`}>
              Project Brief / Query *
            </label>
            <textarea
              id="form-message"
              name="message"
              required
              rows={4}
              value={formData.message}
              onChange={handleChange}
              placeholder="Tell us about your brand goals..."
              className={`px-4 py-3 rounded-xl border transition duration-300 text-sm focus:outline-none focus:border-[#e07f2a] resize-none ${
                isDark 
                  ? "bg-[#221f1f] border-neutral-800 text-white placeholder-neutral-600" 
                  : "bg-white border-neutral-300 text-[#16110f] placeholder-neutral-450"
              }`}
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2 text-center sm:text-left">
            <Button
              variant={isDark ? "orangeSolid" : "solid"}
              type="submit"
              className="w-full sm:w-auto"
            >
              {status.submitting ? "Sending..." : "Submit Inquiry"}
            </Button>
          </div>

        </form>

      </div>
    </section>
  );
}
