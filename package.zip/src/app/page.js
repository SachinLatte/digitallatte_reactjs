import Link from "next/link";
import Button from "./components/ui/Button";
import SectionHeading from "./components/ui/SectionHeading";
import CaseStudyCard from "./components/cards/CaseStudyCard";
import LogoGrid from "./components/sections/LogoGrid";
import ContactSection from "./components/sections/ContactSection";
import services from "../data/services";
import { caseStudies } from "../data/caseStudies";

export const metadata = {
  title: "Best Digital Agency Mumbai | Social Media Marketing | India",
  description: "Digital Latte is a full-service Creative Digital Marketing Agency in Mumbai, India. Get the best digital experts to boost your social media & digital presence.",
};

export default function Home() {
  // Select first 2 case studies for the home page teaser
  const homepageCaseStudies = caseStudies.slice(0, 2);

  const categoryTitles = {
    "digital-services": "Digital Services",
    "design-services": "Creative Design",
    "web-development-services": "Web Development",
    "production-services": "Production & Shoots",
  };

  return (
    <main className="flex-grow flex flex-col w-full font-sans">

      {/* 1. Hero Banner Section */}
      <section className="w-full min-h-screen flex items-center bg-[#ececec]">
        <div className="w-full max-w-[1420px] mx-auto px-6 pt-24 pb-12 md:pt-32 md:pb-20 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">

          {/* Left Side: Content */}
          <div className="md:col-span-7 flex flex-col items-start text-left order-2 md:order-1">
            <h1 className="text-[38px] sm:text-[48px] md:text-[60px] lg:text-[55px] text-[#181414] uppercase leading-[1.2] tracking-[2px] font-light">
              A <span className="font-bold">Full-Service Creative</span> <br className="hidden lg:block"/> Digital Agency
            </h1>
            <p className="text-neutral-700 text-[16px] md:text-[20px] font-medium leading-[1.6] max-w-2xl mt-6">
              Boost your social media & digital marketing strategies with beautiful designs, superior content, and engaging experiences.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button href="/who-we-are" variant="solid">
                Watch Video
              </Button>
              <Button href="/contact-us" variant="outline">
                Get In Touch
              </Button>
            </div>
          </div>

          {/* Right Side: Video Container */}
          <div className="md:col-span-5 flex justify-center order-1 md:order-2 w-full max-w-[380px] md:max-w-none mx-auto">
            <div className="w-full flex justify-center items-center">
              <video
                muted
                playsInline
                autoPlay
                loop
                className="w-full h-auto object-contain"
              >
                <source src="/img/coffee-cup.mp4" type="video/mp4" />
              </video>
            </div>
          </div>

        </div>
      </section>

      {/* 2. Who We Are Section */}
      <section className="home-who-we-are w-full bg-[#16110f] text-white">
        <div className="max-w-[1420px] mx-auto px-6 py-20 md:py-32 grid grid-cols-1 md:grid-cols-12 gap-12 items-center">

          {/* Left Column: Description Content */}
          <div className="md:col-span-6 flex flex-col items-start text-left">
            <SectionHeading 
              title={<><span className="font-bold">Who</span> we are</>}
              theme="dark"
            />
            
            <p className="text-[#868382] text-[15px] md:text-[16px] leading-[1.8] text-justify max-w-xl mt-8 mb-6">
              Digital Latte is a full-service creative digital agency with core expertise in Digital, Design & Development. We emerged from our love for a good cuppa coffee and everything digital. Ever since we've made sure to never run out of coffee or fresh ideas.
            </p>

            <p className="text-[#868382] text-[15px] md:text-[16px] leading-[1.8] text-justify max-w-xl mb-8">
              A team of creative young souls who are passionate about their work and fuelled by our drive to come up with extraordinary ideas, we innovate to brew beyond the ordinary and have the courage to execute these innovative ideas...
            </p>

            <Link
              href="/who-we-are"
              className="text-[#e07f2a] hover:text-[#fff] text-[12px] uppercase tracking-[2px] font-bold underline transition duration-300"
            >
              Read More &rarr;
            </Link>
          </div>

          {/* Right Column: Custom Caricature and Brain Images Side-by-side */}
          <div className="hidden md:grid md:col-span-6 grid-cols-2 gap-6 w-full max-w-[500px] md:max-w-none mx-auto">
            {/* Polaroid 1 (Coffee Caricature) */}
            <div className="pt-[20px]">
              <img
                src="/img/who-we-are-1.webp"
                alt="Digital Latte Coffee Character Caricature"
                className="w-full h-auto object-contain hover:scale-[1.03] transition-transform duration-500 ease-out rounded-xl shadow-lg"
              />
            </div>

            {/* Polaroid 2 (Creative Brain Bulb) */}
            <div>
              <img
                src="/img/who-we-are-2.png"
                alt="Digital Latte Creative Brain Lightbulb"
                className="w-full h-auto object-contain hover:scale-[1.03] transition-transform duration-500 ease-out rounded-xl shadow-lg"
              />
            </div>
          </div>

        </div>
      </section>

      {/* 3. Our Expertise / What We Brew Section */}
      <section className="w-full py-20 md:py-32 bg-[#ececec]">
        <div className="max-w-[1420px] mx-auto px-6 flex flex-col items-center">
          <SectionHeading 
            title={<><span className="font-bold">What</span> we brew</>}
            subtitle="Explore our expertise across creative digital layers, designs, dynamic development, and shoots."
            theme="light"
            align="center"
            className="mb-16"
          />

          {/* Categories Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 w-full">
            {Object.entries(services).map(([category, items]) => (
              <div 
                key={category} 
                className="bg-white border border-neutral-200 hover:border-[#e07f2a] p-8 rounded-2xl transition duration-300 flex flex-col justify-between shadow-sm hover:shadow-md text-left"
              >
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-wider text-[#16110f] border-b border-neutral-100 pb-4 mb-6">
                    {categoryTitles[category] || category.replace("-services", "")}
                  </h3>
                  <ul className="space-y-3 mb-8">
                    {items.slice(0, 4).map((service) => (
                      <li key={service.slug}>
                        <Link 
                          href={`/our-expertise/${category}/${service.slug}`}
                          className="text-[13px] text-neutral-600 hover:text-[#e07f2a] transition duration-300 block py-0.5 uppercase tracking-wider"
                        >
                          &bull; {service.title}
                        </Link>
                      </li>
                    ))}
                    {items.length > 4 && (
                      <li className="text-[11px] text-neutral-400 uppercase font-bold tracking-widest pt-1">
                        + {items.length - 4} More Services
                      </li>
                    )}
                  </ul>
                </div>
                <Button 
                  href={`/our-expertise/${category}`}
                  variant="outline"
                  className="!py-2.5 !text-xs !px-5"
                >
                  View Services
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Clientele Section */}
      <section className="w-full py-20 md:py-32 bg-[#16110f] text-white">
        <div className="max-w-[1420px] mx-auto px-6 flex flex-col items-center">
          <SectionHeading 
            title={<><span className="font-bold">Our</span> clientele</>}
            subtitle="We brew digital relationships with some of the best brands across sports, hospitality, retail, and FMCG sectors."
            theme="dark"
            align="center"
            className="mb-16"
          />

          <LogoGrid />
        </div>
      </section>

      {/* 5. Case Studies Section */}
      <section className="w-full py-20 md:py-32 bg-[#ececec]">
        <div className="max-w-[1420px] mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
            <SectionHeading 
              title={<><span className="font-bold">Recent</span> work</>}
              subtitle="Peep at what we've been brewing to create memorable brand transformations."
              theme="light"
            />
            <Button href="/case-studies" variant="solid" className="mt-6 md:mt-0 self-start md:self-auto">
              View All Case Studies
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {homepageCaseStudies.map((project) => (
              <CaseStudyCard
                key={project.slug}
                slug={project.slug}
                title={project.title}
                description={project.description}
                image={project.image}
                category={project.category}
                stats={project.stats}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 6. Dynamic Contact Section */}
      <ContactSection 
        title="Let's Talk Strategy"
        subtitle="Fuelled by a drive to come up with extraordinary ideas. Drop us a line to discuss your brand goals."
        theme="dark"
      />

    </main>
  );
}
