export const sectors = [
  { id: "all", name: "All Sectors" },
  { id: "fmcg", name: "FMCG / F&B" },
  { id: "retail", name: "Retail & E-commerce" },
  { id: "hospitality", name: "Hospitality & Leisure" },
  { id: "corporate", name: "Corporate & Services" }
];

export const clients = [
  { name: "Tim Hortons", logo: "/img/client-timhortons.png", sector: "fmcg" },
  { name: "Kumar Resorts", logo: "/img/client-kumar.png", sector: "hospitality" },
  { name: "JioNews", logo: "/img/client-jionews.png", sector: "corporate" },
  { name: "Bata", logo: "/img/client-bata.png", sector: "retail" },
  { name: "Godrej", logo: "/img/client-godrej.png", sector: "fmcg" },
  { name: "Sheraton", logo: "/img/client-sheraton.png", sector: "hospitality" },
  { name: "Gold Drop", logo: "/img/client-golddrop.png", sector: "fmcg" },
  { name: "Red Bull", logo: "/img/client-redbull.png", sector: "fmcg" }
];

export const recentWork = [
  { id: 1, title: "Tim Hortons Launch", img: "/img/who-we-are-1.webp", category: "Social Media" },
  { id: 2, title: "Kumar Resorts Promotion", img: "/img/who-we-are-2.png", category: "Design" },
  { id: 3, title: "Bata Festive Campaign", img: "/img/who-we-are-1.webp", category: "Digital Strategy" },
  { id: 4, title: "JioNews App Launch", img: "/img/who-we-are-2.png", category: "Development" }
];
